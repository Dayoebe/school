<?php

namespace App\Livewire\Result;

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\{Result, MyClass, StudentRecord, Semester};
use App\Traits\RestrictsTeacherResultViewing;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class AwardsManager extends Component
{
    use RestrictsTeacherResultViewing;

    public $academicYearId;
    public $semesterId;
    public $selectedClassId;
    public $viewType = 'termly'; // termly or annual
    
    public $classes;
    public $semesters = [];
    public $topPerformers = [];

    public function mount()
    {
        $this->classes = $this->accessibleClassTeacherClassesQuery()
            ->orderBy('name')
            ->get();

        abort_unless($this->currentUserCanAccessClassOnlyResultTools(), 403);

        $school = auth()->user()?->school;

        $this->academicYearId = $school?->academic_year_id;
        $this->semesterId = $school?->semester_id;

        if ($this->isRestrictedTeacherResultViewer() && $this->selectedClassId === null) {
            $this->selectedClassId = $this->classes->first()?->id;
        }
        
        $this->loadSemesters();
        $this->loadTopPerformers();
    }

    #[On('academic-period-changed')]
    public function handlePeriodChange($data)
    {
        $this->academicYearId = $data['academicYearId'];
        $this->semesterId = $data['semesterId'];
        $this->loadSemesters();
        $this->loadTopPerformers();
    }

    public function updatedSelectedClassId()
    {
        $this->loadTopPerformers();
    }

    public function updatedViewType()
    {
        $this->loadTopPerformers();
    }

    protected function loadSemesters()
    {
        if ($this->academicYearId) {
            $this->semesters = Semester::where('academic_year_id', $this->academicYearId)
                ->where('school_id', auth()->user()->school_id)
                ->get();
        } else {
            $this->semesters = collect();
        }
    }

    public function loadTopPerformers()
    {
        if (!$this->academicYearId) {
            $this->topPerformers = collect();
            return;
        }

        if ($this->isRestrictedTeacherResultViewer() && !$this->selectedClassId) {
            $this->topPerformers = collect();
            return;
        }

        // For termly, we need a semester selected
        if ($this->viewType === 'termly' && !$this->semesterId) {
            $this->topPerformers = collect();
            return;
        }

        if ($this->selectedClassId) {
            $classExists = MyClass::where('id', $this->selectedClassId)
                ->whereHas('classGroup', function ($q) {
                    $q->where('school_id', auth()->user()->school_id);
                })
                ->exists();

            if (!$classExists || !$this->currentUserCanViewClassTeacherClass($this->selectedClassId)) {
                $this->topPerformers = collect();
                return;
            }
        }

        $studentRecordIds = StudentRecord::activeStudentRecordIdsForSchoolAcademicYear(
            auth()->user()?->school_id,
            $this->academicYearId,
            $this->selectedClassId ? (int) $this->selectedClassId : null
        );

        if ($studentRecordIds->isEmpty()) {
            $this->topPerformers = collect();
            return;
        }

        // Get results based on view type
        $resultsQuery = Result::whereIn('student_record_id', $studentRecordIds)
            ->where('academic_year_id', $this->academicYearId)
            ->whereHas('studentRecord.user', function ($query) {
                $query->where('school_id', auth()->user()->school_id)
                    ->whereNull('deleted_at');
            });

        if ($this->viewType === 'termly') {
            $resultsQuery->where('semester_id', $this->semesterId);
        } else {
            // Annual - get all semesters
            $resultsQuery->whereIn('semester_id', $this->semesters->pluck('id'));
        }

        $results = $resultsQuery->with([
            'studentRecord' => function($query) {
                $query->with(['user', 'myClass'])
                    ->whereHas('user', function ($q) {
                        $q->where('school_id', auth()->user()->school_id)
                            ->whereNull('deleted_at');
                    });
            }, 
            'subject'
        ])
        ->get();

        if ($results->isEmpty()) {
            $this->topPerformers = collect();
            return;
        }

        // Calculate student performances with proper filtering
        $studentData = [];
        $totalSubjectsPerClass = $this->getTotalSubjectsPerClass();
        
        foreach ($results->groupBy('student_record_id') as $studentId => $studentResults) {
            // Filter out results with null or 0 scores
            $validResults = $studentResults->filter(function($result) {
                return $result->total_score !== null && $result->total_score > 0;
            });
        
            if ($validResults->isEmpty()) {
                continue; // Skip students with no valid scores
            }
        
            $totalScore = $validResults->sum('total_score');
            $average = $validResults->avg('total_score');
        
            // CRITICAL FIX: Check if the student has taken enough subjects
            // Use null-safe operators and check if relationships exist
            $firstResult = $validResults->first();
            
            // Check if studentRecord exists
            if (!$firstResult->studentRecord) {
                continue; // Skip if student record doesn't exist
            }
            
            $studentClass = $firstResult->studentRecord->myClass;
            
            // Check if myClass exists for this student
            if (!$studentClass) {
                continue; // Skip if student doesn't have a class assigned
            }
            
            $expectedSubjectCount = $totalSubjectsPerClass[$studentClass->id] ?? 0;
        
            // Skip if student has taken less than 50% of expected subjects
            $subjectCompletionRatio = $validResults->count() / max($expectedSubjectCount, 1);
            if ($subjectCompletionRatio < 0.5) {
                continue;
            }
            
            $aGrades = $validResults->filter(fn($r) => $r->total_score >= 75)->count();
            
            // Calculate consistency (lower is better) - only for students with at least 3 subjects
            $consistency = 0;
            if ($validResults->count() >= 3) {
                $scores = $validResults->pluck('total_score')->toArray();
                $consistency = $this->calculateStdDev($scores);
            }
        
            $studentData[$studentId] = [
                'student' => $firstResult->studentRecord,
                'total' => $totalScore,
                'average' => round($average, 2),
                'a_grades' => $aGrades,
                'consistency' => round($consistency, 2),
                'subject_count' => $validResults->count(),
                'expected_subjects' => $expectedSubjectCount,
                'completion_ratio' => $subjectCompletionRatio,
            ];
        }

        // If no valid students, return empty
        if (empty($studentData)) {
            $this->topPerformers = collect();
            return;
        }

        // Filter students for eligibility:
        // 1. Must have at least 3 subjects
        // 2. Must have completed at least 50% of expected subjects
        // 3. Must have an average above 40%
        $eligibleStudents = collect($studentData)->filter(function($student) {
            return $student['subject_count'] >= 3 
                   && $student['completion_ratio'] >= 0.5
                   && $student['average'] >= 40;
        });

        if ($eligibleStudents->isEmpty()) {
            $this->topPerformers = collect();
            return;
        }

        // Top 3 by Average (from eligible students only)
        $top3 = $eligibleStudents->sortByDesc('average')
            ->take(3)
            ->map(fn (array $student): array => $this->formatStudentAward($student))
            ->values()
            ->all();

        // Highest Total Score (from eligible students)
        $highestTotal = $eligibleStudents->sortByDesc('total')->first();

        // Most A Grades (from eligible students, at least 1 A grade)
        $mostAs = $eligibleStudents->where('a_grades', '>', 0)
            ->sortByDesc('a_grades')
            ->first();

        // Most Consistent (from eligible students with at least 3 subjects and average >= 50)
        $mostConsistent = $eligibleStudents
            ->filter(fn($s) => $s['subject_count'] >= 3 && $s['average'] >= 50)
            ->sortBy('consistency')
            ->first();

        // Best per subject (filter out 0 scores and require score > 40)
        $bestInSubjects = [];
        foreach ($results->groupBy('subject_id') as $subjectId => $subjectResults) {
            // Filter out 0 scores and require minimum passing score
            $validResults = $subjectResults->filter(fn($r) => 
                $r->total_score !== null && $r->total_score > 40
            );
            
            if ($validResults->isEmpty()) {
                continue;
            }

            $best = $validResults->sortByDesc('total_score')->first();
            
            // Verify this student is in the eligible list
            $studentId = $best->student_record_id;
            if (!isset($studentData[$studentId]) || $studentData[$studentId]['average'] < 40) {
                continue;
            }
            
            $bestInSubjects[] = [
                'subject' => [
                    'name' => $best->subject?->name ?? 'Unknown Subject',
                ],
                'student' => $this->formatStudentSummary($best->studentRecord),
                'score' => (int) $best->total_score,
            ];
        }

        $this->topPerformers = collect([
            'top_3' => $top3,
            'highest_total' => $highestTotal ? $this->formatStudentAward($highestTotal) : null,
            'most_as' => $mostAs ? $this->formatStudentAward($mostAs) : null,
            'most_consistent' => $mostConsistent ? $this->formatStudentAward($mostConsistent) : null,
            'best_in_subjects' => $bestInSubjects,
        ]);
    }

    protected function formatStudentAward(array $studentData): array
    {
        return [
            'student' => $this->formatStudentSummary($studentData['student'] ?? null),
            'total' => (int) ($studentData['total'] ?? 0),
            'average' => (float) ($studentData['average'] ?? 0),
            'a_grades' => (int) ($studentData['a_grades'] ?? 0),
            'consistency' => (float) ($studentData['consistency'] ?? 0),
            'subject_count' => (int) ($studentData['subject_count'] ?? 0),
            'expected_subjects' => (int) ($studentData['expected_subjects'] ?? 0),
            'completion_ratio' => (float) ($studentData['completion_ratio'] ?? 0),
        ];
    }

    protected function formatStudentSummary(?StudentRecord $studentRecord): array
    {
        return [
            'id' => $studentRecord?->id,
            'name' => $studentRecord?->user?->name ?? 'Unknown Student',
            'class_name' => $studentRecord?->myClass?->name ?? 'No Class',
            'profile_photo_url' => $studentRecord?->user?->profile_photo_url ?? asset('images/default-avatar.png'),
        ];
    }

   /**
 * Get total number of subjects expected per class
 */
protected function getTotalSubjectsPerClass(): array
{
    $classes = $this->accessibleClassTeacherClassesQuery()
        ->withCount('subjects')
        ->get();
    $subjectCounts = [];
    
    foreach ($classes as $class) {
        $subjectCounts[$class->id] = $class->subjects_count;
    }
    
    return $subjectCounts;
}

    protected function calculateStdDev($values)
    {
        $count = count($values);
        if ($count === 0) return 0;
        
        $mean = array_sum($values) / $count;
        $variance = array_sum(array_map(fn($x) => pow($x - $mean, 2), $values)) / $count;
        
        return sqrt($variance);
    }

    public function render()
    {
        return view('livewire.result.awards-manager', [
            'isRestrictedTeacherResultViewer' => $this->isRestrictedTeacherResultViewer(),
            'topPerformersData' => $this->topPerformersData(),
        ]);
    }

    protected function topPerformersData(): Collection
    {
        if ($this->topPerformers instanceof Collection) {
            return $this->topPerformers;
        }

        return collect(is_array($this->topPerformers) ? $this->topPerformers : []);
    }
}
