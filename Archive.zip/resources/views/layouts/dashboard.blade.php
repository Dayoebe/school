<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="description"
        content="Elite International College, Awka - A top-tier secondary school dedicated to academic excellence, character development, and future leadership.">
    <meta name="keywords"
        content="Elite International College, Awka, Secondary School in Awka, Nigerian Schools, WAEC, NECO, Best School in Anambra, College Education, Private School Awka">
    <meta name="author" content="Elite International College, Awka">
    <meta name="robots" content="index, follow">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="canonical" href="{{ url()->current() }}">
    <link rel="icon" href="{{ asset('logo.png') }}" type="image/png">
    <link rel="shortcut icon" href="{{ asset(config('app.favicon', 'logo.png')) }}" type="image/png">
    @include('partials.pwa-head', [
        'pwaThemeColor' => '#dc2626',
        'pwaTitle' => $title ?? config('app.name', 'School Portal'),
        'pwaIcon' => asset('logo.png'),
    ])

    <meta property="og:title" content="{{ $title ?? config('app.name', 'Elite International College, Awka') }}">
    <meta property="og:description"
        content="Excellence in education, character, and leadership. Explore admissions, academics, and student life at Elite International College, Awka.">
    <meta property="og:image" content="{{ asset('logo.png') }}">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Elite International College, Awka">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $title ?? config('app.name', 'Elite International College, Awka') }}">
    <meta name="twitter:description"
        content="A leading secondary school in Anambra State focused on academic and moral excellence.">
    <meta name="twitter:image" content="{{ asset('logo.png') }}">

    <title>{{ $title ?? config('app.name', 'Elite International College, Awka') }}</title>

    @vite('resources/css/app.css')
    <livewire:styles />
    @stack('head')
    @include('partials.pwa-register', ['pwaThemeColor' => '#dc2626'])
</head>

<body class="font-sans">
    <a href="#main" class="sr-only">Skip to content</a>

    <div x-data="{ menuOpen: window.innerWidth >= 1024 ? $persist(false) : false }">
        <livewire:layouts.header />

        <div class="lg:flex lg:flex-cols text-gray-900 bg-gray-100 dark:bg-gray-700 dark:text-gray-50 min-h-screen">
            <livewire:layouts.menu />

            <div class="flex min-h-screen w-full max-w-full flex-col overflow-scroll beautify-scrollbar">
                <div class="bg-white dark:bg-gray-800 p-4 w-full border-b-2">
                    <h1 class="text-3xl my-2 capitalize font-semibold flex items-center gap-2">
                        @if (!empty($icon))
                            <i class="{{ $icon }}"></i>
                        @endif
                        <span>{{ $title ?? 'Dashboard' }}</span>
                    </h1>

                    @if (!empty($description))
                        <p class="text-sm text-gray-600 dark:text-gray-300 mb-2">{{ $description }}</p>
                    @endif

                    <div class="w-full">
                        <x-show-set-school />
                    </div>
                    <div class="w-full">
                        @isset($breadcrumbs)
                            <x-breadcrumbs :paths="$breadcrumbs" />
                        @endisset
                    </div>
                </div>

                <main class="flex-1 p-4" id="main">
                    {{ $slot }}
                </main>

                <footer class="border-t border-gray-200 bg-white px-4 py-4 text-sm text-gray-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
                    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                        <p>Created by <a href="https://dayoebe.github.io" target="_blank" rel="noopener noreferrer" class="font-semibold text-red-600 transition hover:text-red-500 dark:text-red-400 dark:hover:text-red-300">Wireless Terminal</a></p>
                        <p>&copy; {{ date('Y') }} {{ config('app.name', 'School Portal') }}</p>
                    </div>
                </footer>
            </div>
        </div>

        @include('partials.dashboard-floating-countdown')
        @livewire('common.display-status')
    </div>

    <livewire:scripts />
    @stack('scripts')
</body>

</html>
